// 돌을 받을 때, 해당 좌표값이 undefined 여야지만 값 입력 가능. 해당 좌표가 undefined가 아니거나 0 미만이거나 18 초과이면 다시 입력 받게 하기. 제대로 입력받으면 브레이크?
// 흰색 돌을 받고, 팔방의 좌표 확인, 있으면 카운트를 하나씩 올려서 카운트가 5 이상일 경우 브레이크, 흰돌 승.

const size = 18;
let current = -1;

let table = new Array(size); // 바둑판 세팅(사이즈 바꾸는 건 생성자 함수로 사이즈 입력받고, 해당 사이즈를 this.size 이런 걸로 받아서 넣기?)
for (let idx = 0; idx < table.length; idx++) {
    table[idx] = new Array(size);
};


function checkPoint(y, x) { // 해당 좌표에 돌을 놓을 수 있는지, 없는지 확인하는 기능
    if (y < 0 || y >= size || x < 0 || x >= size ) {
        console.log("해당 좌표에는 돌을 놓을 수 없습니다.");
        return false;
    } else {
        if ( table[y][x] !== undefined ) {
            console.log("해당 좌표에는 이미 돌이 놓여있습니다.");
            return false;
        } else {
            return true;
        }
    }
};

function checkFive(y, x, color= current) { // 해당 컬러가 5개 이상 이어져 있는지 확인하는 기능
    table[y][x] = color;
    
    let cnt = 0;
    let done = false;

    for ( let i = 0 ; i < size ; i++ ) { // 수직 체크
        if ( table[i][x] === color ) {
            cnt++;
        } else { // 중간에 끊기면 0으로 초기화
            cnt = 0;
        };
        if ( cnt >= 5 ) {
            done = true;
            break;
        };
    };

    for ( let i = 0 ; i < size ; i++ ) { // 수평 체크
        if ( table[y][i] === color ) {
            cnt++;
        } else {
            cnt = 0;
        };
        if ( cnt >= 5 ) {
            done = true;
            break;
        };
    };

    let ix = 0;
    let iy = 0;
    let r = x > y ? y : x

    for ( ix = x - r, iy = y - r; ix < size && iy < size; ix++, iy++) { // 위에서부터 대각선 아래로(++) 체크
        if (table[iy][ix] === color ) {
            cnt++;
        } else {
            cnt = 0;
        };
        if ( cnt >= 5) {
            done = true;
            break;
        };
    };
    
    for ( iy = y - r, ix = x + r ; iy < size && ix >= 0 ; iy++, ix-- ) { // 아래서부터 대각선 위로(+-) 체크
        if (table[iy][ix] === color ) {
            cnt++;
        } else {
            cnt = 0;
        };
        if ( cnt >= 5) {
            done = true;
            break;
        };
    };

    return done;
};



